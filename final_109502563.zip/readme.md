### Compiler final project
## 程式執行方式
* 確定有python環境後執行 `main.py` 檔案即可
```bash
python3 main.py < <test_file_name> 
```
或是已經有寫好的 shell 檔案
* 執行 `test.sh` & `bonus.sh`，可以直接跑基本測資跟加分測資